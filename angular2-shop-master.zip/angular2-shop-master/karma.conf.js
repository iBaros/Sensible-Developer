// Look in `./config` for `karma.conf.js`
exports.config = require('./config/karma.conf.js');
