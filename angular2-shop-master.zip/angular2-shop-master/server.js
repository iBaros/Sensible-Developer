// *server.js*
require("babel-register");
// Load server main file 
var app = require('./server.main.js');
