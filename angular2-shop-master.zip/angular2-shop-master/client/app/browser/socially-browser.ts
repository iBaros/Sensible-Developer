import 'reflect-metadata';

export * from "./auth/login";
export let APP_COMPONENT_BROWSER_TEMPLATE = "/packages/socially-browser/app/app.html";