//auth.service.ts

import {Injectable} from '@angular/core';


@Injectable()
export class SharedService {
	public userId:string;
	//public userId2:any;
	
	public userEmail:string;
	//public data ={};
	constructor(   ) {
	  //alert('ggg');
	  this.userId='ffffff';
	  
  }
	
	
}