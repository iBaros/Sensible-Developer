import 'reflect-metadata';
import {IONIC_DIRECTIVES} from 'ionic-webpack-package';

export * from "./auth/login";
export let MOBILE_IMPORTS = IONIC_DIRECTIVES;
export let APP_COMPONENT_MOBILE_TEMPLATE = "/packages/socially-mobile/app/app.html";