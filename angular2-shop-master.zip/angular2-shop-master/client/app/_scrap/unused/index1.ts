export {environment} from './environment';
export {Material2AppAppComponent} from './material2-app.component';
