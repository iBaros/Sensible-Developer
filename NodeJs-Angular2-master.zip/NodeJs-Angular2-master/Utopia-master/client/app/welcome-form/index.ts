﻿export * from './welcome.component';
export * from './welcome.service';