export interface Steps {
    name?: string;
    email?: string;
    password?: string;
    age?: number;
    gender?: string;
    profession?: string;
    about?:string;
    city?:string;
    news?: string;
    art?: string;
    health?: string;
    food?: string;
    sports?: string;
    technology?: string;
}
